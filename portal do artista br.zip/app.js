let musicas = JSON.parse(localStorage.getItem("musicas")) || [];

function render(){
    let lista = document.getElementById("lista");
    lista.innerHTML = "";

    musicas.forEach((m, i)=>{
        lista.innerHTML += `
        <div class="music">
            <b>${m.nome}</b>
            <br>
            <audio controls src="${m.url}" onended="proxima(${i})"></audio>
            <br>
            <button onclick="interesse('${m.nome}')">Tenho Interesse</button>
        </div>
        `;
    });
}

function addMusic(){
    let nome = document.getElementById("musicName").value;
    let url = document.getElementById("musicUrl").value;

    if(!nome || !url){
        alert("Preencha todos os campos!");
        return;
    }

    musicas.push({nome, url});
    localStorage.setItem("musicas", JSON.stringify(musicas));

    render();
}

// 🔥 AUTOPLAY (próxima música)
function proxima(i){
    let audios = document.querySelectorAll("audio");

    if(audios[i+1]){
        audios[i+1].play();
    }
}

// 🔥 BOTÃO INTERESSE MELHORADO
function interesse(nome){
    let mensagem = prompt("Digite seu interesse (ex: comprar, proposta, show):");

    if(mensagem){
        alert("Interesse enviado para: " + nome);
        console.log({
            musica: nome,
            mensagem: mensagem
        });
    }
}

window.onload = render;